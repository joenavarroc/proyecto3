package repositories;

public class VentaRepository {
    
}
