package repositories;

public class VendedorRepository {
    
}
