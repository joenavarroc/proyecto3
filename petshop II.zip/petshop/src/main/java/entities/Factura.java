package entities;

import java.time.LocalDate;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class Factura {
    private String letra;
    private int numero;
    private LocalDate fecha;
    private double monto;
    private int idCliente;
    private int legajoVendedor;
}
