package petshop.repositories;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import petshop.connectors.Connector;
import petshop.entities.Venta;
import petshop.enums.Letra;

public class VentaRepository {
    private Connection conn = Connector.getConnection();

    public void save(Venta venta) {
        if (venta == null) return;
        try (PreparedStatement ps = conn.prepareStatement(
                "insert into ventas (letra,numero,codigo,cantidad) values (?,?,?,?)",
                PreparedStatement.RETURN_GENERATED_KEYS)) {
            ps.setString(1, venta.getLetra().toString());
            ps.setInt(2, venta.getNumero());
            ps.setInt(3,venta.getCodigo());
            ps.setInt(4, venta.getCantidad());
            ps.execute();
            ResultSet rs = ps.getGeneratedKeys();
            if (rs.next())
                venta.setCodigo(rs.getInt(3));
        } catch (Exception e) {
            System.out.println(e);
        }
    }

    public void remove(Venta venta){
        if(venta == null) return;
        try (PreparedStatement ps = conn.prepareStatement(
            "delete from ventas where letra=? and numero=?")){
            ps.setString(1, venta.getLetra().toString());
            ps.setInt(2, venta.getNumero());
            ps.execute();    
        } catch (Exception e) {
            System.out.println(e);
        } 
    }

    public List<Venta> getAll() {
        List<Venta> list = new ArrayList();
        try (ResultSet rs = conn
                .createStatement()
                .executeQuery("select * from ventas")) {
            while (rs.next()) {
                list.add(new Venta(
                    Letra.valueOf(rs.getString("letra")),
                    rs.getInt("numero"),
                    rs.getInt("codigo"),
                    rs.getInt("cantidad")));
            }
        } catch (Exception e) {
            System.out.println(e);
        }
        return list;
    }
    
    public Venta getByVenta(Letra letra, int numero){
        return getAll()
                        .stream()
                        .filter(venta->venta.getLetra()==letra)
                        .filter(venta->venta.getNumero()==numero)
                        .findFirst() 
                        .orElse(new Venta()); 
    }

    public List<Venta>getByCodigo(int codigo) {
        return getAll()
                        .stream()
                        .filter(venta -> venta.getCodigo() == codigo)
                        .collect(Collectors.toList());
    }
}
