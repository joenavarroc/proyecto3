package petshop.controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;



import petshop.entities.Articulo;
import petshop.repositories.ArticuloRepository;

// @Data
// @NoArgsConstructor
// @AllArgsConstructor
public class ArticuloController {
    private String mensaje="Igrese un producto";
    private ArticuloRepository articuloRepository= new ArticuloRepository();
    // private String producto;
    // private int stock;
    // private double precio;

    @GetMapping("/articulos")
    public String getArticulos(Model model, @RequestParam(name = "buscar", defaultValue = "")String buscar){
        Articulo articulo=new Articulo();
        articulo.setStock(1);
        model.addAttribute("mensaje", mensaje);
        model.addAttribute("articulo", articuloRepository.getAll());
        model.addAttribute("likeProducto", articuloRepository.getLikeProducto(buscar));
        return "articulos";
    }

    @PostMapping("/articulosSave")
    public String articulosSave(@ModelAttribute Articulo articulo){
        System.out.println("***************************************");
        System.out.println(articulo);
        System.out.println("***************************************");
        articuloRepository.save(articulo);
        if (articulo.getCodigo()>0){
            mensaje="Se guardo el codigo: "+articulo.getCodigo();
        } else {
            mensaje="Error! No se guardo el articulo!";
        }
        return "redirec:articulos";
    }
}