package petshop.controllers;

import petshop.enums.Letra;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class Factura {
    private Letra letra;
    private int numero;
    private String fecha;
    private double monto;
    private int idCliente;
    private int legajoVendedor;
}
