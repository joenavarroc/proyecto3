-- Active: 1714155149639@@127.0.0.1@3306@colegio
drop database if exists petshop;
create database petshop;
use petshop;
drop table if exists clientes;
drop table if exists articulos;
drop table if exists vendedores;
drop table if exists ventas;
drop table if exists facturas;

create table clientes(
	idCliente int auto_increment primary key,
    nombre varchar(50) not null,
    apellido varchar(50)not null,
    dni char(8)not null,
    telefono varchar(10),
    email varchar(50)
);

create table facturas(
	letra char(1),
    check(letra in('A','B','C')),
    numero int,
    fecha date not null,
    monto double not null,
    idCliente int,
    legajoVendedor int,
    primary key (letra,numero)   
);

create table articulos(
	codigo int auto_increment primary key,
    producto varchar(100) not null,
    stock int not null,
    precio int not null
);

create table vendedores(
	legajo int auto_increment primary key,
    nombre varchar(50) not null,
    apellido varchar(50) not null,
    dni char(8) not null
);

create table ventas(
	letra char(1),
    numero int,
    codigo int,
    cantidad int not null,
    primary key (letra,numero,codigo)
);

alter table facturas 
add constraint FK_facturas_idCliente
foreign key(idCliente)
references clientes(idCliente);

alter table facturas
add constraint FK_facturas_legajoVendedor
foreign key(legajoVendedor)
references vendedores(legajo);

alter table ventas
add constraint FK_ventas_codigo
foreign key(codigo)
references articulos(codigo);

alter table ventas
add constraint FK_ventas_numero
foreign key(letra,numero)
references facturas(letra,numero);
     
    


