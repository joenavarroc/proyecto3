use petshop;

INSERT INTO clientes (nombre, apellido, dni, telefono, email) VALUES
	('Juan', 'Perez', '12345678', '987654321', 'juan.perez@gmail.com'),
    ('María', 'Flores', '87654321', '123456789', 'maria.flores@gmail.com'),
    ('Carlos', 'Rodriguez', '23456789', '567890123', 'carlos.rodriguez@hotmail.com'),
    ('Lucía', 'Franco', '34567812', '654321789', 'lucia.franco@outlook.com'),
    ('Martín', 'Díaz', '98765432', '321789456', null),
    ('Carolina', 'López', '45678123', '789456123', 'carolina.lopez@gmail.com'),
    ('Fernando', 'Martínez', '78901234', '456123789', 'fernando.martinez@yahoo.com.ar'),
    ('Valeria', 'García', '12345678', '123789456', null),
    ('Miguel', 'Sánchez', '56781234', '789456123', 'miguel.sanchez@gmail.com'),
    ('Camila', 'Fernández', '12347890', '456789012', 'camila.fernandez@outlook.com'),
    ('Diego', 'Britos', '78904561', '234567890', null),
    ('Brenda', 'Giménez', '34561230', '567890123', 'brenda.gimenez@gmail.com'),
    ('Marcelo', 'Alvarez', '78904561', '234567890', 'marcelo.alvarez@hotmail.com'),
    ('Romina', 'Smith', '34561230', '567890123', null),
    ('Eduardo', 'Romero', '12034567', '678901234', 'eduardo.romero@gmail.com');

INSERT INTO facturas (letra, numero, fecha, monto, idCliente, legajoVendedor) VALUES
    ('A', 1, '2023-01-01', 150.00, 1, 1),
    ('B', 1, '2023-03-21', 200.00, 2, 2),
    ('B', 2, '2023-02-03', 100.00, 1, 3),
    ('A', 2, '2023-06-04', 120.00, 4, 4),
    ('C', 1, '2023-07-31', 180.00, 15, 5),
    ('A', 3, '2023-11-06', 90.00, 13, 6),
    ('A', 4, '2023-01-01', 200.00, 7, 7),
    ('B', 3, '2023-09-10', 150.00, 8, 8),
    ('C', 2, '2023-08-09', 120.00, 9, 9),
    ('C', 3, '2023-03-25', 160.00, 10, 10),
    ('A', 5, '2023-07-30', 190.00, 1, 1),
    ('B', 4, '2023-04-02', 110.00, 11, 2),
    ('C', 4, '2023-01-13', 130.00,7, 3),
	('B', 5, '2023-12-14', 160.00, 3, 10),
    ('C', 5, '2023-12-14', 190.00, 6, 1),
    ('C', 6, '2023-12-15', 130.00,14, 3);

INSERT INTO vendedores (nombre, apellido, dni) VALUES
    ('Luis', 'Montiel', '34567890'),
    ('Bruno', 'Lamberti', '45678901'),
    ('Mariano', 'Quiroga', '56789012'),
    ('Joseph', 'Navarro', '90876543'),
    ('Francisco', 'Firus', '76543210'),
    ('Pablo', 'Torres', '54321098'),
    ('Laura', 'Rojas', '21098765'),
    ('Sebastián', 'Pérez', '45678901'),
    ('Melina', 'Cabrera', '12309876'),
    ('Ana', 'Vargas', '65432109');    

INSERT INTO articulos (codigo, producto, stock, precio) VALUES
    (1, 'balanceado', 100, 15000),
    (2, 'antipulgas', 50, 12000),
    (3, 'rascador', 10, 1500),
    (4, 'correa', 70, 5000),
    (5, 'pretal', 68, 8000),
    (6, 'collar', 83, 600),
    (7, 'piedras', 40, 400),
    (8, 'litera', 10, 30000),
    (9, 'huesos', 150, 250),
    (10, 'vacunas', 15, 26500),
    (11, 'bebedero', 36, 4500),
    (12, 'comedero', 74, 35),
    (13, 'transportadora', 3, 70000)

 INSERT INTO ventas (letra, numero, codigo, cantidad) VALUES
    ('A', 1, 1, 5),
    ('B', 1, 2, 3),
    ('C', 1, 3, 2),
    ('A', 2, 4, 2),
    ('B', 2, 8, 3),
    ('C', 2, 6, 1),
    ('A', 3, 7, 4),
    ('B', 3, 8, 2),
    ('A', 4, 9, 3),
    ('A', 5, 10, 2),
    ('B', 4, 11, 3),
    ('C', 3, 8, 1),
    ('C', 4, 13, 4);    