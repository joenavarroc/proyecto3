package repositories;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import connector.Connector;

import entities.Vendedor;

public class VendedorRepository {
    private Connection conn = Connector.getConnection();

    public void save(Vendedor vendedor) {
        if (vendedor == null) return;
        try (PreparedStatement ps = conn.prepareStatement(
                "insert into vendedores (legajo,nombre,apellido,dni) values (?,?,?,?)",
                PreparedStatement.RETURN_GENERATED_KEYS)) {
            ps.setInt(1, vendedor.getDni());
            ps.setString(2, vendedor.getNombre());
            ps.setString(3, vendedor.getApellido());
            ps.setInt(4, vendedor.getDni());
            ps.execute();
            ResultSet rs = ps.getGeneratedKeys();
            if (rs.next())
                vendedor.setLegajo(1);
        } catch (Exception e) {
            System.out.println(e);
        }
    }

    public void remove(Vendedor vendedor){
        if(vendedor == null) return;
        try (PreparedStatement ps = conn.prepareStatement(
            "delete from vendedor where legajo=?")){
            ps.setInt(1, vendedor.getLegajo());
            ps.execute();    
        } catch (Exception e) {
            System.out.println(e);
        } 
    }

    public List<Vendedor> getAll() {
        List<Vendedor> list = new ArrayList();
        try (ResultSet rs = conn
                .createStatement()
                .executeQuery("select from vendedor")) {
            while (rs.next()) {
                list.add(new Vendedor(
                        rs.getInt("legajo"),
                        rs.getString("nombre"),
                        rs.getString("apellido"),
                        rs.getInt("dni")));
            }
        } catch (Exception e) {
            System.out.println(e);
        }
        return list;
    }

    public Vendedor getByLegajo(int legajo){
        return getAll()
                        .stream()
                        .filter(vendedor->vendedor.getLegajo()==legajo)
                        .findFirst() 
                        .orElse(new Vendedor()); 
    }

    public List<Vendedor>getLikeLegajo(int legajo) {
        return getAll()
                        .stream()
                        .filter(vendedor -> String.valueOf(vendedor.getLegajo()).contains(String.valueOf(legajo)))
                        .collect(Collectors.toList());
    }
}
