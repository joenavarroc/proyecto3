package repositories;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import connector.Connector;
import entities.Vendedor;
import entities.Venta;

public class VentaRepository {
    private Connection conn = Connector.getConnection();

    public void save(Venta venta) {
        if (venta == null) return;
        try (PreparedStatement ps = conn.prepareStatement(
                "insert into ventas (letra,numero,codigo,cantidad) values (?,?,?,?)",
                PreparedStatement.RETURN_GENERATED_KEYS)) {
            ps.setString(1, venta.getLetra());
            ps.setInt(2, venta.getNumero());
            ps.setInt(3, venta.getCodigo());
            ps.setInt(4, venta.getCantidad());
            ps.execute();
            ResultSet rs = ps.getGeneratedKeys();
            if (rs.next())
                venta.setNumero(1);
        } catch (Exception e) {
            System.out.println(e);
        }
    }

    public void remove(Venta venta){
        if(venta == null) return;
        try (PreparedStatement ps = conn.prepareStatement(
            "delete from ventas where numero=?")){
            ps.setInt(1, venta.getNumero());
            ps.execute();    
        } catch (Exception e) {
            System.out.println(e);
        } 
    }

    public List<Venta> getAll() {
        List<Venta> list = new ArrayList();
        try (ResultSet rs = conn
                .createStatement()
                .executeQuery("select from ventas")) {
            while (rs.next()) {
                list.add(new Venta(
                        rs.getString("letra"),
                        rs.getInt("numero"),
                        rs.getInt("codigo"),
                        rs.getInt("cantidad")));
            }
        } catch (Exception e) {
            System.out.println(e);
        }
        return list;
    }

    public Venta getByNumero(int numero){
        return getAll()
                        .stream()
                        .filter(venta->venta.getNumero()==numero)
                        .findFirst() 
                        .orElse(new Venta()); 
    }

    
    public List<Venta>getLikeNumero(int numero) {
        return getAll()
                        .stream()
                        .filter(venta -> String.valueOf(venta.getNumero()).contains(String.valueOf(numero)))
                        .collect(Collectors.toList());
    }
}
