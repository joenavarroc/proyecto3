package petshop.petshop;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PetshopApplicationTests {

	@Test
	void contextLoads() {
	}

}
