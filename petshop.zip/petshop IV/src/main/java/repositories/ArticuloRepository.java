package repositories;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import connector.Connector;
import entities.Articulo;

public class ArticuloRepository {
    private Connection conn = Connector.getConnection();

    public void save(Articulo articulo) {
        if (articulo == null) return;
        try (PreparedStatement ps = conn.prepareStatement(
                "insert into articulos (codigo,producto,stock,precio) values (?,?,?,?)",
                PreparedStatement.RETURN_GENERATED_KEYS)) {
            ps.setInt(1, articulo.getCodigo());
            ps.setString(2, articulo.getProducto());
            ps.setInt(3, articulo.getStock());
            ps.setDouble(4, articulo.getPrecio());
            ps.execute();
            ResultSet rs = ps.getGeneratedKeys();
            if (rs.next())
                articulo.setProducto(rs.getString(1));
        } catch (Exception e) {
            System.out.println(e);
        }
    }

    public void remove(Articulo articulo){
        if(articulo == null) return;
        try (PreparedStatement ps = conn.prepareStatement(
            "delete from articulos where producto=?")){
            ps.setString(1, articulo.getProducto());
            ps.execute();    
        } catch (Exception e) {
            System.out.println(e);
        } 
    }

    public List<Articulo> getAll() {
        List<Articulo> list = new ArrayList();
        try (ResultSet rs = conn
                .createStatement()
                .executeQuery("select * from articulos")) {
            while (rs.next()) {
                list.add(new Articulo(
                        rs.getInt("codigo"),
                        rs.getString("producto"),
                        rs.getInt("stock"),
                        rs.getDouble("precio")));
            }
        } catch (Exception e) {
            System.out.println(e);
        }
        return list;
    }

    public Articulo getByProducto(String producto){
        return getAll()
                        .stream()
                        .filter(articulo->articulo.getProducto()==producto)
                        .findFirst() 
                        .orElse(new Articulo()); 
    }

    public List<Articulo>getLikeProducto(String producto) {
        if(producto==null) return new ArrayList();
        return getAll()
                        .stream()
                        .filter(articulo->articulo
                                                .getProducto()
                                                .toLowerCase()
                                                .contains(producto.toLowerCase()))
                        .toList();
    }
}
