package petshop.controllers;


import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;


import petshop.entities.Articulo;
import petshop.repositories.ArticuloRepository;


@Controller
public class ArticuloController {
    
    private String mensaje="Ingrese un producto";
    private ArticuloRepository articuloRepository= new ArticuloRepository();

    @GetMapping("/articulos")
    public String getArticulos(Model model, @RequestParam(name = "buscar", defaultValue = "")String buscar){
        Articulo articulo=new Articulo();
       
        model.addAttribute("mensaje", mensaje);
        model.addAttribute("articulo", articulo);
        model.addAttribute("likeProducto", articuloRepository.getLikeProducto(buscar));
        return "articulos";
    }

    @PostMapping("/articulosSave")
    public String articulosSave(@ModelAttribute Articulo articulo){
        System.out.println("***************************************");
        System.out.println(articulo);
        System.out.println("***************************************");
        articuloRepository.save(articulo);
        if (articulo.getCodigo()>0){
            mensaje="Se guardo el Articulo: "+articulo.getCodigo();
        } else {
            mensaje="Error! No se guardo el Articulo!";
        }
        return "redirect:articulos";
    }
}