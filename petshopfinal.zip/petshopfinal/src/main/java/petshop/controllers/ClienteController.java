package petshop.controllers;


import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;


import petshop.entities.Cliente;
import petshop.repositories.ClienteRepository;


@Controller
public class ClienteController {
    
    private String mensaje="Ingrese un cliente";
    private ClienteRepository clienteRepository= new ClienteRepository();

    @GetMapping("/clientes")
    public String getClientes(Model model, @RequestParam(name = "buscar", defaultValue = "")String buscar){
        Cliente cliente=new Cliente();
       
        model.addAttribute("mensaje", mensaje);
        model.addAttribute("cliente", cliente);
        model.addAttribute("likeApellido", clienteRepository.getLikeApellido(buscar));
        model.addAttribute("likeNombre", clienteRepository.getLikeNombre(buscar));
        return "clientes";
    }

    @PostMapping("/clientesSave")
    public String clientesSave(@ModelAttribute Cliente cliente){
        System.out.println("***************************************");
        System.out.println(cliente);
        System.out.println("***************************************");
        clienteRepository.save(cliente);
        if (cliente.getIdCliente()>0){
            mensaje="Se guardo el Cliente: "+cliente.getIdCliente();
        } else {
            mensaje="Error! No se guardo el Cliente!";
        }
        return "redirect:clientes";
    }
}