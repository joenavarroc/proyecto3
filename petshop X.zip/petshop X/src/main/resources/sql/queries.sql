-- Active: 1716432186751@@127.0.0.1@3306@colegio
-- Lista de clientes
select * from clientes;

-- Informar la cantidad de facturas de cada cliente.
select c.nombre, c.apellido, count(*) cantidad_facturas
from
    clientes c
    join facturas f on c.idCliente = f.idCliente
    join ventas v on v.letra = f.letra
    and v.numero = f.numero
    join articulos a on a.codigo = v.codigo
group by
    c.nombre,
    c.apellido;
    
-- Listar que clientes (idCliente, nombre, apellido) que compraron balanceado.
select  c.idCliente, c.nombre, c.apellido
from 	clientes c
join	facturas f on c.idCliente=f.idCliente
join	ventas v on f.letra=v.letra and f.numero=v.numero
join 	articulos a on v.codigo=a.codigo
where	a.producto = 'Balanceado';
    
-- Listar que clientes (idCliente, nombre, apellido) que compraron balanceado.
select c.idCliente, c.nombre, c.apellido
from
    clientes c
    join facturas f on c.idCliente = f.idCliente
    join ventas v on f.letra = v.letra
    and f.numero = v.numero
    join articulos a on v.codigo = a.codigo
where
    a.producto = 'Balanceado';

-- Listar la cantidad de facturas que hubo por fecha de facturacion.
select fecha, count(*) cantidad_facturas
from facturas
group by
    fecha;

-- Listar los clientes a los que no se le haya hecho alguna factura.
select *
from clientes c
    left join facturas f on c.idCliente = f.idCliente
where
    letra is null;

-- Listar clientes cuyos apellidos teminen con 'Z'.
select * from clientes where apellido like '%z';

-- Cuantos clientes tiene un email resgistrado, ordenados por apellido, nombre.
select apellido, nombre, email
from clientes
where
    email is not null
order by apellido;

-- Listar nombre y apellido, tanto de clientes como de vendedores, cuya direccion de email sea Gmail.
select * from clientes where email like '%gmail%';

-- Informar cuantas unidades se vendieron de cada articulo.
select a.codigo, a.producto, sum(cantidad) total_articulos
from
    articulos a
    join ventas v on a.codigo = v.codigo
    join facturas f on v.letra = f.letra
    and v.numero = f.numero
group by
    a.codigo, a.producto;

-- Informar quienes compraron el primer dia de ventas.
select c.nombre, c.apellido, min(fecha)
from
    clientes c
    join facturas f on c.idCliente = f.idCliente
    join ventas v on v.letra = f.letra
    and v.numero = f.numero
where
    fecha = (
        select min(fecha)
        from facturas
    )
group by
    f.numero,f.letra;