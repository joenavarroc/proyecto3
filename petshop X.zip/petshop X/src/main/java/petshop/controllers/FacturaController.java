package petshop.controllers;


import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;


import petshop.entities.Factura;
import petshop.repositories.FacturaRepository;


@Controller
public class FacturaController {
    
    private String mensaje="Igrese una factura";
    private FacturaRepository facturaRepository= new FacturaRepository();

    @GetMapping("/facturas")
    public String getClientes(Model model, @RequestParam(name = "buscar", defaultValue = "")String buscar){
        Factura factura=new Factura();
       
        model.addAttribute("mensaje", mensaje);
        model.addAttribute("factura", factura);
        model.addAttribute("likeIdCliente", facturaRepository.getLikeIdCliente(0));
        model.addAttribute("likeIdCliente", facturaRepository.getByIdCliente(0));
        return "facturas";
    }

    @PostMapping("/facturasSave")
    public String facturasSave(@ModelAttribute Factura factura){
        System.out.println("***************************************");
        System.out.println(factura);
        System.out.println("***************************************");
        facturaRepository.save(factura);
        if (factura.getIdCliente()>0){
            mensaje="Se guardo la Factura: "+factura.getIdCliente();
        } else {
            mensaje="Error! No se guardo la Factura!";
        }
        return "redirect:facturas";
    }
}