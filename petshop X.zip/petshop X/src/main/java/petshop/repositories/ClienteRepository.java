package petshop.repositories;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import petshop.connectors.Connector;
import petshop.entities.Cliente;

public class ClienteRepository {
    private Connection conn = Connector.getConnection();

    public void save(Cliente cliente) {
        if (cliente == null) return;
        try (PreparedStatement ps = conn.prepareStatement(
                "insert into clientes (idCliente,nombre,apellido,dni,telefono,email) values (?,?,?,?,?,?)",
                PreparedStatement.RETURN_GENERATED_KEYS)) {
            ps.setInt(1, cliente.getIdCliente());
            ps.setString(2, cliente.getNombre());
            ps.setString(3, cliente.getApellido());
            ps.setInt(4, cliente.getDni());
            ps.setString(5, cliente.getTelefono());
            ps.setString(6, cliente.getEmail());
            ps.execute();
            ResultSet rs = ps.getGeneratedKeys();
            if (rs.next())
                cliente.setIdCliente(rs.getInt(1));
        } catch (Exception e) {
            System.out.println(e);
        }
    }

    public void remove(Cliente cliente){
        if(cliente == null) return;
        try (PreparedStatement ps = conn.prepareStatement(
            "delete from clientes where idCliente=?")){
            ps.setInt(1, cliente.getIdCliente());
            ps.execute();    
        } catch (Exception e) {
            System.out.println(e);
        } 
    }

    public List<Cliente> getAll() {
        List<Cliente> list = new ArrayList();
        try (ResultSet rs = conn
                .createStatement()
                .executeQuery("select * from clientes")) {
            while (rs.next()) {
                list.add(new Cliente(
                        rs.getInt("idCliente"),
                        rs.getString("nombre"),
                        rs.getString("apellido"),
                        rs.getInt("dni"),
                        rs.getString("telefono"),
                        rs.getString("email")));
            }
        } catch (Exception e) {
            System.out.println(e);
        }
        return list;
    }

    public Cliente getByIdCliente(int idCliente){
        return getAll()
                        .stream()
                        .filter(cliente->cliente.getIdCliente()==idCliente)
                        .findFirst() 
                        .orElse(new Cliente()); 
    }

    public List<Cliente>getLikeApellido(String apellido) {
        if(apellido==null) return new ArrayList();
        return getAll()
                        .stream()
                        .filter(cliente->cliente
                                                .getApellido()
                                                .toLowerCase()
                                                .contains(apellido.toLowerCase()))
                        .toList();
    }
}


